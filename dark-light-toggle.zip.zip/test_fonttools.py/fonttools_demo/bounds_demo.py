from fontTools.ttLib import TTFont
from fontTools.pens.boundsPen import BoundsPen

# Load a font file
font = TTFont("C:/Windows/Fonts/arial.ttf")
glyph_set = font.getGlyphSet()

# Use BoundsPen to calculate bounding box of glyph 'A'
pen = BoundsPen(glyph_set)
glyph_set["A"].draw(pen)

print("Bounds of 'A':", pen.bounds)
