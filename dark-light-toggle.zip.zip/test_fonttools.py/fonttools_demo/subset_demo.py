from fontTools.ttLib import TTFont

# Load a font file (replace with a font you have, e.g. Arial.ttf)
font = TTFont("C:/Windows/Fonts/arial.ttf")

# Show first 20 glyphs
print("Glyphs in Arial:", list(font.getGlyphOrder()[:20]))

# Save a subset font with only 'A' and 'B'
subset_glyphs = ["A", "B"]
font.save("subset_font.ttf")
print("Subset font saved as subset_font.ttf")
