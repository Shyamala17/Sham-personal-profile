import fontTools

print("FontTools version:", fontTools.__version__)
