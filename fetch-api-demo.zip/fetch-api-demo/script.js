// Select DOM elements
const fetchBtn = document.getElementById("fetchBtn");
const countryInput = document.getElementById("countryInput");
const resultDiv = document.getElementById("result");
const loadingDiv = document.getElementById("loading");

/**
 * Fetch country information using Fetch API
 * Demonstrates asynchronous behavior:
 * - fetch() returns a Promise (async operation)
 * - .then() handles resolved responses
 * - .catch() handles rejected Promises (errors)
 */
function fetchCountryInfo() {
  const countryName = countryInput.value.trim();

  if (!countryName) {
    resultDiv.textContent = "⚠️ Please enter a country name.";
    return;
  }

  // Show loading indicator while data is being fetched
  loadingDiv.style.display = "block";
  resultDiv.textContent = "";

  // Asynchronous HTTP request using Fetch API
  fetch(`https://restcountries.com/v3.1/name/${countryName}`)
    .then(response => {
      // Conditional check for failed responses
      if (!response.ok) {
        throw new Error(`Country not found (status: ${response.status})`);
      }
      // Convert response to JSON (also async, returns a Promise)
      return response.json();
    })
    .then(data => {
      // Extract required fields from JSON
      const country = data[0];
      resultDiv.innerHTML = `
        <strong>${country.name.common}</strong><br>
        Capital: ${country.capital ? country.capital[0] : "N/A"}<br>
        Region: ${country.region}<br>
        Population: ${country.population.toLocaleString()}<br>
        Flag: <img src="${country.flags.png}" alt="Flag of ${country.name.common}" width="100">
      `;
    })
    .catch(error => {
      // Error handling for network issues or invalid responses
      resultDiv.textContent = "❌ Error fetching data: " + error.message;
      console.error("Error:", error);
    })
    .finally(() => {
      // Hide loading indicator after request completes (success or error)
      loadingDiv.style.display = "none";
    });
}

// Event listener for button click
fetchBtn.addEventListener("click", fetchCountryInfo);
