Product,Region,Sales
Laptop,North,1200
Laptop,South,800
Phone,North,600
Phone,East,900
Tablet,West,400
Tablet,South,700
